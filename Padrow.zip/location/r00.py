import telebot 
def send_url(message, id, token) :
 bot = telebot.TeleBot(token)
 print(id)
 print(token)
 bot.send_message(id, message)


